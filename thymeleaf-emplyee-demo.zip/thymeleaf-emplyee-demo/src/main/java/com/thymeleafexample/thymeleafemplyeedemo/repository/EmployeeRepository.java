package com.thymeleafexample.thymeleafemplyeedemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
 
import com.thymeleafexample.thymeleafemplyeedemo.model.*;
 
@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Long> {
 
}