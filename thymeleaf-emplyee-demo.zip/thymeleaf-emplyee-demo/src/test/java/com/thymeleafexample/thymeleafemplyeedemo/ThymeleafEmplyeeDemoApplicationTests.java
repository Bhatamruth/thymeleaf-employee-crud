package com.thymeleafexample.thymeleafemplyeedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafEmplyeeDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
